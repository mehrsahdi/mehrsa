//مهرسااحمدی  40223002

#include <stdio.h>


int main ()
{
    int n,i,j;
    printf("Enter a positive inteeger number : ");
    scanf("%d", &n);

    char a[n];
    printf("Enter a text expression of lengh %d : ", n);
    scanf("%s",a);

    for(i=0;i<n-1;i++)
    {
        if(a[i]==a[i+1])
        {
            for(j=i;j<n-1;j++)
            {
                a[j]=a[j+2];
                a[j+1]=a[j+3];
            }
        i=-1;
        n-=2;
        printf("%s\n", a);
 
        }

    }

return 0;
}